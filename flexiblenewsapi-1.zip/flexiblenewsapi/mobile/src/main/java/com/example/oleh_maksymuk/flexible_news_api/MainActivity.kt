package com.example.oleh_maksymuk.flexible_news_api

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.*
import android.view.Menu
import android.view.MenuItem
import com.example.oleh_maksymuk.flexible_news_api.adapter.ArticleListAdapter
import com.example.oleh_maksymuk.flexible_news_api.service.NewApiService
import com.example.oleh_maksymuk.flexible_news_api.service.ResponseHandler
import com.example.oleh_maksymuk.flexible_news_api.service.model.GetTopLinesResponse

class MainActivity : AppCompatActivity() {

    private val newApiService = NewApiService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configureToolbar()

        configureListView()
    }

    private fun configureListView() {

        newApiService.getTopLines(object : ResponseHandler<GetTopLinesResponse> {
            override fun onResult(result: GetTopLinesResponse) {
                val recyclerView = findViewById<RecyclerView>(R.id.articles_list)
                val articleListAdapter = ArticleListAdapter(result.articles, this@MainActivity)
                val dividerItemDecoration = DividerItemDecoration(applicationContext, RecyclerView.VERTICAL)
                recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                recyclerView.itemAnimator = DefaultItemAnimator()
                recyclerView.adapter = articleListAdapter
                recyclerView.addItemDecoration(dividerItemDecoration)
            }
        })
    }

    private fun configureToolbar() {
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
