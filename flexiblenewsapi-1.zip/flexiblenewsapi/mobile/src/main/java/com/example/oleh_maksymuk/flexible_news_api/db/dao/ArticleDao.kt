package com.example.oleh_maksymuk.flexible_news_api.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.oleh_maksymuk.flexible_news_api.service.model.Article

@Dao
interface ArticleDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun saveArticle(vararg article: Article)

    @Query("SELECT * from article")
    fun getArticles(): List<Article>
}