package com.example.oleh_maksymuk.flexible_news_api.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.oleh_maksymuk.flexible_news_api.MainActivity
import com.example.oleh_maksymuk.flexible_news_api.R
import com.example.oleh_maksymuk.flexible_news_api.service.model.Article
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.article_list_item.view.*
import java.net.URI

class ArticleListAdapter(val articles: List<Article>, var parrentActivity: Activity) :
    RecyclerView.Adapter<ArticleListAdapter.ArticleListAdapterViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleListAdapterViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.article_list_item, parent, false)
        return ArticleListAdapterViewHolder(itemView, parent)
    }

    override fun getItemCount(): Int = articles.size

    override fun onBindViewHolder(holder: ArticleListAdapterViewHolder, position: Int) {
        val article = articles[position]
        holder.articleTitle.text = article.title
        holder.articleDescription.text = article.description
        Picasso.with(holder.viewGroup.context).load(Uri.parse(article.urlToImage)).into(holder.articleImage)

        holder.followLink.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(article.url))
            parrentActivity.startActivity(intent)
        }
    }


    class ArticleListAdapterViewHolder(
        itemView: View,
        val viewGroup: ViewGroup,
        val articleTitle: TextView = itemView.findViewById(R.id.article_title),
        val articleDescription: TextView = itemView.findViewById(R.id.article_description),
        val articleImage: ImageView = itemView.findViewById(R.id.article_image),
        val followLink: Button = itemView.findViewById(R.id.follow_article_link)
    ) : RecyclerView.ViewHolder(itemView)


}