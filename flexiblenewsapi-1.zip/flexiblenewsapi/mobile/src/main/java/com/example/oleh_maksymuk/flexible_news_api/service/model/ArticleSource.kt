package com.example.oleh_maksymuk.flexible_news_api.service.model

data class ArticleSource(
    val id: String = "",
    val name: String = ""
)