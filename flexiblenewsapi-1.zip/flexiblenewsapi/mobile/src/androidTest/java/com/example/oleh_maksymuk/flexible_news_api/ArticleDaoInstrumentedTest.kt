package com.example.oleh_maksymuk.flexible_news_api

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.oleh_maksymuk.flexible_news_api.db.dao.AppDatabase
import com.example.oleh_maksymuk.flexible_news_api.db.dao.ArticleDao
import com.example.oleh_maksymuk.flexible_news_api.service.model.Article
import com.example.oleh_maksymuk.flexible_news_api.service.model.ArticleSource
import org.junit.*
import org.junit.runner.RunWith
import java.io.IOException

@RunWith(AndroidJUnit4::class)
class ArticleDaoInstrumentedTest {

    private var articleDao: ArticleDao
    private var db: AppDatabase

    constructor() {
        val appContext = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(
            appContext, AppDatabase::class.java).build()
        articleDao = db.articleDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    @Throws(Exception::class)
    fun writeUserAndReadInList() {
        val article: Article = Article(
            "DEFAULT_AUTHOR",
            "DEFAULT_TITLE",
            "DEFAULT_DESC",
            "https://default.uri.com",
            "https://default.imageuri.com",
            "DEFAULT_PUBLISHED_AT",
            "DEFAULT_CONTENT",
            ArticleSource(
                "DEFAULT_SOURCE_ID",
                "DEFAULT_SOURCE_NAME"
            )
        )

        articleDao.saveArticle(article)


        val articles = articleDao.getArticles()

        print("")
//        userDao.insert(user)
//        val byName = userDao.findUsersByName("george")
//        assertThat(byName.get(0), equalTo(user))
    }
}